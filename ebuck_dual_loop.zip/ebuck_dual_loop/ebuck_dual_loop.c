//#############################################################################
//#############################################################################
//
// FILE:   3 Interrupts Flow by Writing to Registers Directly.c
//
//-----------------------------------------------------------------------------
//
// >>>> PeakcurrentSensor Notes
//
// * CMPSS4 COMPH comparator is used to compare the input and the internal DAC
// * The internal DAC reference = VDDA = 3.3V
// * Input pin: ADCIN14 (CMPIN4P)
// * Output pin: GPIO14 (OUTPUTXBAR3) (CTRIPOUTH)
// * CTRIPH = CTRIPOUTH = ASYNCH = COMPH high
// * GPIO14 triggers interrupt "ISR_PeakcurrentSensor"
// * Internal DAC can be set to other values
//-----------------------------------------------------------------------------
//
// >>>> Offtime timer Notes
//
// * ePWM1 module, ePWM1A channel
// * Count down mode
//
//-----------------------------------------------------------------------------
//
// >>>> Switch Notes
//
// * GPIO61 acts as the output of switch: 1 = on, 0 = off
//-----------------------------------------------------------------------------
//
// >>>> Sensor Notes
//
// * Convert voltage on ADCC by software trigger
// * C4 should be connected to a signal acting as positive input (i.e. pin ADCINC4)
// * C5 should be connected to a signal acting as negative input (i.e. pin ADCINC5)
// * adcCResult0 (and sensor.vSensor) stores digital representation of the voltage: ADCINC4 - ADCINC5
// * Converted digital value = 65536 * (ADCINA0 - ADCINA1 + VREFHI) / (2 * VREFHI),
// * where VREFHI is believed to be the output voltage of chip OPA350 on the LaunchPad, which is 3.0V
//-----------------------------------------------------------------------------
//
// >>>> DAC Notes
//
// * Generate a voltage on the buffered DAC output DACOUTB/ADCINA1
// * Voltage reference is ADC VREFHI,
// * which is believed to be the output voltage of chip OPA350 on the LaunchPad, which is 3.0V
// * V_out = DACVALA * VREFHI / 4096 = dacVal * 3.0V / 4096 (on pin A1)
//
//#############################################################################
//#############################################################################


//#############################################################################
//
// Included Files
//
//#############################################################################
#include "F28x_Project.h"
// ==== #include "off_timer.h" ====
typedef void (*Offtimer_init)(void);
typedef void (*Offtimer_reset)(void);
typedef uint16_t (*Offtimer_read)(void);
typedef void (*Offtimer_start)(void);
typedef void (*Offtimer_stop)(void);
typedef void (*Offtimer_intp)(char e);

struct TIMER
{
    uint32_t periodOff;                                         // Set the offtimer period, might range from 1us to 30us
    char flagOff;                                               // Once the timer finished counting, flagOff is set to 1
    Offtimer_init  initOff;                                     // Initialize EPWM
    Offtimer_reset resetOff;                                    // Reset EPWM counter
    Offtimer_read  readOff;                                     // Read EPWM counter value
    Offtimer_start startOff;                                    // Start EPWM counter
    Offtimer_stop  stopOff;                                     // Stop EPWM counter
    Offtimer_intp  intpOff;                                     // Enable or disable the Offtimer interrupt: enable = 1, disable = 0
} timer;

// ==== #include "sensor.h" ====
#define EX_ADC_RESOLUTION    ADC_RESOLUTION_16BIT               // Resolution: 16 bit
#define EX_ADC_SIGNAL_MODE   ADC_MODE_DIFFERENTIAL              // Differential mode

typedef void (*Sensor_init)(void);
typedef void (*Sensor_start)(void);
typedef void (*Sensor_intp)(char e);

struct SENSOR                                                   // Inner-loop sensor: getting the output voltage
{
    int flagSensor;                                             // Once sensor finished data acquisition, flagSensor is set to 1
    long int vSensor;                                           // Store sensing value
    Sensor_init initSensor;                                     // Initialize ADC
    Sensor_start startSensor;                                   // Start the sensor
    Sensor_intp intpSensor;                                     // Enable or disable the sensor interrupt: enable = 1, disable = 0
}sensor;

// ==== #include "actuator.h" ====
typedef void (*Actuator_init)(void);
typedef void (*Actuator_start)(long int);

struct ACTUATOR                                                 // Voltage-loop actuator: getting the output voltage
{
    Actuator_init initActuator;                                 // Initialize DAC
    Actuator_start startActuator;                               // Start the conversion
}actuator;

// ==== #include "currentsensor.h" ====
typedef void (*currentsensor_init)(void);
typedef void (*currentsensor_intp)(char e);

struct CURRENTTSRENSER
{
    currentsensor_init initAct;                                 // Initialize CMPSS4 COMPH
    currentsensor_intp intpAct;                                 // Enable or disable the PeakcurrentSensor interrupt: enable = 1, disable = 0
}currentsensor;

// ==== #include "switchOut.h" ====
typedef void (*Switch_func)(void);

struct SWITCHOUT
{
    Switch_func initSwitch;                                     // Initialize GPIO61
    Switch_func onSwitch;                                       // Output 1
    Switch_func offSwitch;                                      // Output 0
}switchOut;

// Constants Defines
//
//#############################################################################

// Offtimer
#define EPWM1_TIMER_TBPRD    6000U                                // Time base period TBPRD in 16 bits <=65536
#define EPWM1_CMPA           5800U                                 // Counter compare CMPA

// Parameters
const long int kp=17;
const long int ki=4;
const long int kpp=320;
const long int kii=80;
const long int kt=1;

// 16bit differential ADC is 3V referred, the voltage divider ratio is 1
const long int Vref1=49179;  //1.5  65536<->3V
const long int Vref2=54643;  //2
const long int Tref=600;    // 525 approximate to be 11us 90kHz
// a typical transient is 400ns
// 12bit DAC is 3.3V referred, sampling res is 50mohm
const long int max_control=3813376;//3724<->(9.23A) 3813376=2^10*3724
const long int min_control=349472;   //341 <-> 0.85A 349472=2^10*341

long int Vref;

long int ipk;
long int ipkp;

long int pre_ontime;
long int pre_ontime_p;

long int e;
long int ep;

long int period;

//#############################################################################
//
// Globals
//
//#############################################################################

int *p = 0x00004004;                                            // Timer:    pointer to TBCTR

//#############################################################################
//
// Modules Function Pointer Prototype
//
//#############################################################################

// Interrupts Prototypes
__interrupt void ISR_CurrentSensor(void);
__interrupt void ISR_Timer(void);
__interrupt void ISR_Sensor(void);

//#############################################################################
//
// CurrentSensor Functions
//
//#############################################################################

void initCMPSS(void)                                            // Configure the high comparator of CMPSS4
{
    EALLOW;

    // Enable CMPSS and configure the negative input signal to come from the DAC
    Cmpss4Regs.COMPCTL.bit.COMPDACE = 1;
    Cmpss4Regs.COMPCTL.bit.COMPHSOURCE = 0;

    // Use VDDA as the reference for the DAC: VDDA = 3.3V
    Cmpss4Regs.COMPDACCTL.bit.SELREF = 0;

    // Define when the internal DAC value is loaded from its shadow register
    Cmpss4Regs.COMPDACCTL.bit.SWLOADSEL = 0;                    // From SYSCLK

    // Specify the DAC value source for the high comparator's internal DAC
    Cmpss4Regs.COMPDACCTL.bit.DACSOURCE = 0;                    // From DACHVALS

    // Set DAC value to midpoint for arbitrary reference: midpoint = 1.65V
    // Value 0 ~ 4095
    Cmpss4Regs.DACHVALS.bit.DACVAL = 1000;

    Cmpss4Regs.COMPCTL.bit.COMPHSOURCE=0;

    // Configure the output signals
    // Both CTRIPH and CTRIPOUTH will be fed by Digital Filter output signal (synchronous comparator output)
    Cmpss4Regs.COMPCTL.bit.CTRIPHSEL = 2;
    Cmpss4Regs.COMPCTL.bit.CTRIPOUTHSEL = 2;

    // Digital Filter Design
    Cmpss4Regs.CTRIPLFILCTL.bit.FILINIT=1;
    Cmpss4Regs.CTRIPLFILCTL.bit.SAMPWIN=31;
    Cmpss4Regs.CTRIPLFILCTL.bit.THRESH=25;
    Cmpss4Regs.CTRIPLFILCLKCTL.bit.CLKPRESCALE=2;

    // Setup the Output3 X-BAR to output CTRIPOUTH on OUTPUTXBAR3(GPIO14)
    OutputXbarRegs.OUTPUT3MUX0TO15CFG.bit.MUX6 = 0;             // MUX 6.0 = CMPSS4.CTRIPOUTH
    OutputXbarRegs.OUTPUT3MUXENABLE.bit.MUX6 = 1;

    // Configure GPIO14 to output CTRIPOUT1H (routed through OUTPUTXBAR3)
    // GPIO_SetupPinMux(14, GPIO_MUX_CPU1, 6);

    GpioCtrlRegs.GPAGMUX1.bit.GPIO14=1;
    GpioCtrlRegs.GPAMUX1.bit.GPIO14=2;         ///
    EDIS;

    // ===== CMPSS intp config =====
    EALLOW;
    InputXbarRegs.INPUT4SELECT = 0xE;                           // GPIO14 is XINT1
    EDIS;

    XintRegs.XINT1CR.bit.POLARITY = 0;                          // Configure XINT1: Falling edge interrupt

}

void intpCMPSS(char e)                                          // Enable or disable the currentSensor interrupt
{
    if(e == 1)
    {
        XintRegs.XINT1CR.bit.ENABLE = 1;                        // Enable XINT1: INT1.4
    }
    else
    {
        XintRegs.XINT1CR.bit.ENABLE = 0;                        // Disable XINT1: INT1.4
    }
}

//#############################################################################
//
// Timer Functions
//
//#############################################################################

void initEPWM(void)                                             // Initialize ePWM1 module
{
    timer.periodOff = EPWM1_TIMER_TBPRD;

    EALLOW;

    // Disable SOCA
    EPwm1Regs.ETSEL.bit.SOCAEN = 0;

    // EPWMCLK = PLLSYSCLK
    // TBCLK = EPWMCLK / ( highSpeedPrescaler * pre-scaler )
    ClkCfgRegs.PERCLKDIVSEL.bit.EPWMCLKDIV = 0;
    EPwm1Regs.TBCTL.bit.CLKDIV = 0;
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = 0;

    // Configure GPIO0 as ePWM1A
    GPIO_SetupPinMux(0, GPIO_MUX_CPU1, 1);

    // Set-up TBCLK period
    EPwm1Regs.TBPRD = EPWM1_TIMER_TBPRD;
    EPwm1Regs.TBCTL.bit.PHSEN = 0;                              // Disable phase loading
    EPwm1Regs.TBPHS.bit.TBPHS = 0x0000;                         // Phase is 0
    EPwm1Regs.TBCTR = 0;

    // Set compare value CMPA
    EPwm1Regs.CMPA.bit.CMPA = EPWM1_CMPA;

    // Set up shadowing: load when counter = period
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = 0;                         // Shadow mode, not immediate mode
    EPwm1Regs.CMPCTL.bit.LOADAMODE = 1;                         // Load on CTR = PRD

    // Set actions: counter = CMPA  ==> set high; counter = zero  ==> set low
    EPwm1Regs.AQCTLA.bit.CAD = 3;                               // Toggle EPWM1A output high when CTR = CMPA, down
    //EPwm1Regs.AQCTLA.bit.ZRO = 1;                               // Force EPWM1A output low when CTR = ZERO

    // ===== EPWM intp config =====

    // Select SOC on "Time base counter equals to CMPA, decrement" event
    EPwm1Regs.ETSEL.bit.SOCASELCMP = 0;
    EPwm1Regs.ETSEL.bit.SOCASEL = 5 ;

    // Generate INT on every event
    EPwm1Regs.ETPS.bit.SOCPSSEL = 0;
  //  EPwm1Regs.ETPS.bit.SOCACNT  = 1;
    EPwm1Regs.ETPS.bit.SOCAPRD  = 1;
    EDIS;
}

void resetEPWM(void)                                            // Reset the counter
{
    // Freeze the time base counter
    EPwm1Regs.TBCTL.bit.CTRMODE = 3;

    // Set the time base counter to period because of count-down mode
    EPwm1Regs.TBCTR = 0;

    // Set flag to zero
   // timer.flagOff = 0;
}

uint16_t readEPWM(void)                                         // Read the counter
{
    return (*p);                                                // Read the time-based counter value
}

void startEPWM(void)                                            // Start the counter
{
    // Start the time-based counter by setting up counter mode: count down
    EPwm1Regs.TBCTL.bit.CTRMODE = 1;
}

void stopEPWM(void)                                             // Stop the counter
{
    // Stop the time base counter
    EPwm1Regs.TBCTL.bit.CTRMODE = 3;
}

void intpEPWM(char e)                                           // Enable or disable timer interrupt
{
    if (e == 1)
    {
        EPwm1Regs.ETSEL.bit.SOCAEN = 1;                          // Enable EPWM1 SOCA interrupt
    }
    else
    {
        EPwm1Regs.ETSEL.bit.SOCAEN = 0;                          // Disable EPWM1 SOCA interrupt
    }
}

//#############################################################################
//
// Switch Functions
//
//#############################################################################

void initSwitchOut(void)                                        // Initialize GPIO61
{
    EALLOW;

    GpioCtrlRegs.GPBPUD.bit.GPIO61 = 0;                         // Enable pullup on GPIO61

    GpioCtrlRegs.GPBGMUX2.bit.GPIO61 = 0;
    GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 0;                        // GPIO61 = GPIO61

    GpioCtrlRegs.GPBDIR.bit.GPIO61 = 1;                         // Output

    EDIS;
}

void onSwitchOut(void)
{
    GpioDataRegs.GPBSET.bit.GPIO61 = 1;
}

void offSwitchOut(void)
{
    GpioDataRegs.GPBCLEAR.bit.GPIO61 = 1;
}

//#############################################################################
//
// Sensor Functions
//
//#############################################################################

void initADC(void)                                              // Configure and power up ADCC + Configure SOC0 of ADCC
{
    EALLOW;

    // Set ADCCLK divider to 1, ADCCLK = PLLSYSCLK
    // ADCCLK is used to clock the conversion phase, while sample and hold phase is clocked by SYSCLK
    AdccRegs.ADCCTL2.bit.PRESCALE = 0;

    // Set resolution and signal mode and load corresponding trims
    AdcSetMode(ADC_ADCC, ADC_RESOLUTION_16BIT, ADC_SIGNALMODE_DIFFERENTIAL);

    // Set pulse positions to late
    AdccRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    // Power up the ADCs and then delay for 1 ms
    AdccRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    DELAY_US(1000);                                             // Delay at least 500us after enableConverter()

    // Configure SOC0 of ADCC
    // SOC0 converts pin C4 and C5, triggered by epwm1_SOCA
    // For 16-bit resolution, a sampling window of 64 (320 ns at a 200MHz SYSCLK rate) will be used
    AdccRegs.ADCSOC0CTL.bit.TRIGSEL = 5;
    AdccRegs.ADCSOC0CTL.bit.CHSEL = 4;                          // ADCIN4 & ADCIN5
    AdccRegs.ADCSOC0CTL.bit.ACQPS = 63;                         // S+H window = ACQPS + 1

    // ===== ADC intp config =====

    // Set SOC0 as the source of the interrupt
    AdccRegs.ADCINTSEL1N2.bit.INT1SEL = 0;


    EDIS;
}

void startADC(void)                                             // Start the conversion
{
    AdccRegs.ADCSOCFRC1.bit.SOC0 = 1;                           // Start ADC
}

void intpADC(char e)                                            // Enable or disable the ADC interrupt
{
    if(e == 1)
    {
        EALLOW;
        AdccRegs.ADCINTSEL1N2.bit.INT1E = 1;                    // Enable ADCCINT1 interrupt
        EDIS;
    }
    else
    {
        EALLOW;
        AdccRegs.ADCINTSEL1N2.bit.INT1E = 0;                    // Disable ADCCINT1 interrupt
        EDIS;
    }
}

//#############################################################################
//
// Actuator Functions
//
//#############################################################################

void configureDAC(void)
{
   /* EALLOW;

    // Set ADC VREFHI as the DAC reference voltage
    DacbRegs.DACCTL.bit.DACREFSEL = 1;

    // Enable the DAC output
    DacbRegs.DACOUTEN.bit.DACOUTEN = 1;

    // Set the DAC shadow output to 0
    DacbRegs.DACVALS.bit.DACVALS = 0;

    // Delay for buffered DAC to power up
    DELAY_US(1000);

    EDIS;
    */
}

void outputDAC(long int ipk)
{
    // Set DAC output value and output
   EALLOW;
   Cmpss4Regs.DACHVALS.bit.DACVAL = (ipk>>10);
   EDIS;
}

//#############################################################################
//
// Controller
//
//#############################################################################

void Controller(unsigned long int voltage)
{
   e=Vref-voltage;
   ipk=ipkp+ki*e+kp*(e-ep);
   // Controller saturation setting
              if (ipk>=max_control)
                {ipk=max_control;}
              else if  (ipk<=min_control)
                {ipk=min_control;}
              else {}
    ep=e;
    ipkp=ipk;
}

void Controller2(unsigned long int voltage)
{
   e=Vref-voltage;
   ipk=ipkp+kii*e+kpp*(e-ep);
   // Controller saturation setting
              if (ipk>=max_control)
                {ipk=max_control;}
              else if  (ipk<=min_control)
                {ipk=min_control;}
              else {}
    ep=e;
    ipkp=ipk;
}

//#############################################################################
//
// Other Functions
//
//#############################################################################

void InitVar()
{
    Vref=Vref1;
    ep=Vref;
    ipkp=0;
    pre_ontime_p=0;
}

//#############################################################################
//
// Main
//
//#############################################################################

void main(void)
{
    //####################################################################
    //          Preprocessing: pointers + general initialization
    //####################################################################

    // CurrentSensor
   currentsensor.initAct = initCMPSS;
    currentsensor.intpAct = intpCMPSS;
    // Switch
    switchOut.initSwitch = initSwitchOut;
    switchOut.onSwitch = onSwitchOut;
    switchOut.offSwitch = offSwitchOut;
    // Timer
    timer.initOff = initEPWM;
    timer.resetOff = resetEPWM;
    timer.intpOff = intpEPWM;
    timer.readOff = readEPWM;
    timer.startOff = startEPWM;
    timer.stopOff = stopEPWM;
    // Sensor
    sensor.initSensor = initADC;
    sensor.intpSensor = intpADC;
    sensor.startSensor = startADC;
    sensor.vSensor = 0;
    sensor.flagSensor = 0;
    // Actuator
    actuator.initActuator = configureDAC;
    actuator.startActuator = outputDAC;

    // disable watch dog
    EALLOW;
    WdRegs.SCSR.bit.WDOVERRIDE=1;
    WdRegs.WDCR.bit.WDDIS=1;
    EDIS;

    // cpu watch dog
    CpuSysRegs.RESC.bit.WDRSn=1;

    // Initialize device clock and peripherals
    InitSysCtrl();

    // Disable pin locks and enable internal pullups
    InitGpio();

    // Clear all interrupts and initialize PIE vector table:
    // 1. Disable CPU interrupts
    DINT;

    // 2. Initialize the PIE control registers to their default state
    // The default state is all PIE interrupts disabled and flags are cleared
    InitPieCtrl();

    // Disable CPU interrupts and clear all CPU interrupt flags
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize the PIE vector table with pointers to the shell Interrupt Service Routines (ISR)
    InitPieVectTable();

    // ##########################################
    //          Initialize 5 structures
    // ##########################################

    // Initialize CurrentSensor
    currentsensor.initAct();

    // Initialize Switch
    switchOut.initSwitch();

    // Initialize Timer
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;                       // Disable sync (freeze clock to ePWM)
    EDIS;
    // After Initialization, timer is stopped and stay on = time period
    timer.initOff();

    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;                       // Enable sync and clock to ePWM
    EDIS;

    // Initialize Sensor
    sensor.initSensor();

    // Initialize Actuator
    actuator.initActuator();                                    // Configure DAC module

    //###########################################################
    //          Set up GPIO monitoring & debug \iables
    //###########################################################

    EALLOW;

    GpioCtrlRegs.GPADIR.bit.GPIO4 = 1;                          // Set GPIO4 as output
    GpioDataRegs.GPASET.bit.GPIO4 = 1;                          // Set GPIO4 high

    GpioCtrlRegs.GPADIR.bit.GPIO5 = 1;                          // Set GPIO5 as output
    GpioDataRegs.GPASET.bit.GPIO5 = 1;                          // Set GPIO5 high

    GpioCtrlRegs.GPADIR.bit.GPIO15 = 1;                         // Set GPIO15 as output

    GpioCtrlRegs.GPADIR.bit.GPIO16 = 1;                         // Set GPIO16 as output

    EDIS;


    //#####################################
    //          Enable Interrupts
    //#####################################

    // Interrupts that are used in this example are re-mapped to ISR functions found within this file.
    EALLOW;
    PieVectTable.XINT1_INT = &ISR_CurrentSensor;
    PieVectTable.EPWM1_INT = &ISR_Timer;
    PieVectTable.ADCC1_INT = &ISR_Sensor;
    EDIS;

    // Enable CPU & PIE interrupts

    // 1. XINT1
    // Enable CPU INT1: Group 1
    IER |= M_INT1;
    // Enable PIE interrupt: Group 1 interrupt 4
    PieCtrlRegs.PIEIER1.bit.INTx4 = 1;

    // 2. EPWM1
    // Enable CPU INT3: Group 3
    IER |= M_INT3;
    // Enable PIE interrupt: Group 3 interrupt 1
    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;

    // 3. ADCC1
    // Enable CPU INT1: Group 1
    IER |= M_INT1;
    // Enable PIE interrupt: Group 1 interrupt 3
    PieCtrlRegs.PIEIER1.bit.INTx3 = 1;

    // Enable global Interrupts and higher priority real-time debug events:
    EINT;                                                       // Enable Global interrupt INTM
    ERTM;                                                       // Enable Global realtime interrupt DBGM

    // #################
    //       Start
    // #################
    InitVar();
    // Enable Sensor interrupt
    sensor.intpSensor(1);
    // Enable EPWM
   timer.intpOff(1);
    // Indicating beginning of the main_code
     GpioDataRegs.GPACLEAR.bit.GPIO15 = 1;

      Vref=Vref1;
      //  Start Timer
     timer.startOff();
     // Turn on Switch
       switchOut.onSwitch();

      DELAY_US(100000);
      GpioDataRegs.GPASET.bit.GPIO15 = 1;
      Vref=Vref2;


    // Loop indefinitely
    while(1)
    {
        //EALLOW;
        //WdRegs.WDKEY.all=0x0055;
        //WdRegs.WDKEY.all=0x00AA;
      //EDIS;
        /*
        if(EPwm1Regs.TBCTR<=1000)
        {
            switchOut.onSwitch();
timer.resetOff();
                timer.startOff();
        }
        */
    }

}

//#############################################################################
//
// ISR Functions
//
//#############################################################################

__interrupt void ISR_Timer(void)
{
    timer.resetOff();

    // Clear EPWM1 INT flag
    while(EPwm1Regs.ETFLG.bit.INT==1)
    {
    EPwm1Regs.ETCLR.bit.INT = 1;
    }

    PieCtrlRegs.PIEIFR3.bit.INTx1 = 0;                          // Clear PIE flag (could be commented out)
    IFR &= ~M_INT3;                                             // Clear CPU flag (could be commented out)

    // Acknowledge this interrupt
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

    // Start ADC sampling
    sensor.startSensor();
}


__interrupt void ISR_Sensor(void)
{
    GpioDataRegs.GPASET.bit.GPIO4 = 1;
    // timer.resetOff();
     sensor.vSensor = AdccResultRegs.ADCRESULT0;
     if (Vref==Vref1)
         Controller(sensor.vSensor);
     else
         Controller2(sensor.vSensor);
     actuator.startActuator(ipk);

     // Turn off Switch
     switchOut.offSwitch();

     // Acknowledge this interrupt
     PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

     DELAY_US(1.6);
     AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;                      // Clear ADCINT1 flag


     // Enable PeakcurrentSensor interrupt
     currentsensor.intpAct(1);
     PieCtrlRegs.PIEIFR1.bit.INTx4 = 0;
     if(GpioDataRegs.GPADAT.bit.GPIO14==0)
               {
                    currentsensor.intpAct(0);                                   // Disable CurrentSensor interrupt
                    PieCtrlRegs.PIEIFR1.bit.INTx4 = 0;                          // Clear XINT1 PIE flag
                    IFR &= ~M_INT1;
                    switchOut.onSwitch();
                    timer.resetOff();
                    timer.startOff();
               }
}

__interrupt void ISR_CurrentSensor(void)
{
    GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;
    currentsensor.intpAct(0);                                   // Disable CurrentSensor interrupt
    PieCtrlRegs.PIEIFR1.bit.INTx4 = 0;                          // Clear XINT1 PIE flag
    IFR &= ~M_INT1;                                             // Clear CPU flag
    // Turn on Switch
    switchOut.onSwitch();

    // Acknowledge this interrupt
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

    timer.resetOff();
    timer.startOff();
}


//
// End of File
//
